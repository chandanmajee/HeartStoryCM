window.addEventListener('load',()=>{
setTimeout(()=>{
const l=document.getElementById('loader');
l.style.opacity='0';
l.style.visibility='hidden';
},1000);
});

const box=document.getElementById('hearts');
const e=['❤️','💕','💖','💗'];
setInterval(()=>{
const h=document.createElement('div');
h.className='heart';
h.textContent=e[Math.floor(Math.random()*e.length)];
h.style.left=Math.random()*100+'vw';
h.style.fontSize=(18+Math.random()*20)+'px';
box.appendChild(h);
setTimeout(()=>h.remove(),8000);
},250);

document.getElementById('startBtn').onclick=()=>{
alert('Welcome to HeartStoryCM ❤️');
};
